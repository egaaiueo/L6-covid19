@extends('layouts.app')

@section('content')
<style type="text/css">
	img{
		width: 300px;
	}
</style>
    <!-- Icon -->
    <div class="fadeIn first">
      <img src="../img/coronavirus.png" alt="User Icon" />
      <h1>
          {{ Auth::user()->name }}
      </h1>
  	</div>

	<center>
		<h2>Result</h2>
		<p><strong>Total Jawaban Ya</strong> : <label id="yes">{{ $survey->yes }}</label></p>
		@if($survey->yes>-1 & $survey->yes<8)         
        	<p>
        		<strong>Status:</strong>
        		<label id="status">Resiko Rendah</label>
        	</p>     
        	@elseif($survey->yes>7 & $survey->yes<15)
        	<p>
        		<strong>Status :</strong>
        		<label id="status">Resiko Sedang</label>
        	</p>
        	@else
        	<p>
        		<strong>Status :</strong>
        		<label id="status">Resiko Tinggi</label>
        	</p>
        @endif
    </center>

	@guest
    @else
    <a style="margin-top: 15px;" class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="fa fa-sign-out"></i> {{ __('Logout') }} </a>
    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
    @csrf
    </form>
    @endguest

@endsection


