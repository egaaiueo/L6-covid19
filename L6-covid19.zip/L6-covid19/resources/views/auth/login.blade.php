@extends('layouts.app')

@section('content')
    <div class="fadeIn first">
      <img src="../img/coronavirus.png" id="icon" alt="User Icon" />
      <h1>SURVEI COVID19</h1>
    </div>

<!-- Login Form -->
    <form method="POST" action="{{ route('login') }}">
        @csrf
            <div class="col-md-12">
                <input id="email" type="email" class="fadeIn second @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus placeholder="Email Address">
                    @error('email')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
            </div>
            <div class="col-md-12">
                <input id="password" type="password" class="fadeIn third @error('password') is-invalid @enderror" name="password" required autocomplete="current-password" placeholder="Passowrd">
                    @error('password')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
            </div>
            <input type="submit" class="fadeIn fourth" value="Log In">
    </form>

    <!-- Remind Passowrd -->
    <div id="formFooter">
      <a class="underlineHover" href="{{route('register')}}">Register</a>
    </div>
@endsection
