@extends('layouts.app')

@section('content')
    <div class="fadeIn first">
      <img src="../img/coronavirus.png" id="icon" alt="User Icon" />
      <h1>SURVEI COVID19</h1>
    </div>

<!-- Login Form -->
    <form method="POST" action="{{ route('register') }}">
        @csrf
            <div class="col-md-12">
                <input id="name" type="text" class="fadeIn second @error('name') is-invalid @enderror" name="name" value="{{ old('name') }}" required autocomplete="name" autofocus placeholder="Nama">
                    @error('name')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
            </div>
            <div class="col-md-12">
                <input id="email" type="email" class="fadeIn third @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" placeholder="Email Address">
                    @error('email')
                        <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                        </span>
                    @enderror
            </div>
            <div class="col-md-12">
                <input id="password" type="password" class="fadein third @error('password') is-invalid @enderror" name="password" required autocomplete="new-password" placeholder="Password">
                    @error('password')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
            </div>
            <div class="col-md-12">
                <input id="password-confirm" type="password" class="fadein fourth" name="password_confirmation" required autocomplete="new-password" placeholder="Password Confirm">            
            </div>
            <input type="submit" class="fadeIn fourth" value="Register">
    </form>
@endsection
