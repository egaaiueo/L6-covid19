<?php $__env->startSection('content'); ?>
<style type="text/css">
	img{
		width: 300px;
	}
</style>
    <!-- Icon -->
    <div class="fadeIn first">
      <img src="../img/coronavirus.png" alt="User Icon" />
      <h1>
          <?php echo e(Auth::user()->name); ?>

      </h1>
  	</div>

	<center>
		<h2>Result</h2>
		<p><strong>Total Jawaban Ya</strong> : <label id="yes"><?php echo e($survey->yes); ?></label></p>
		<?php if($survey->yes>-1 & $survey->yes<8): ?>         
        	<p>
        		<strong>Status:</strong>
        		<label id="status">Resiko Rendah</label>
        	</p>     
        	<?php elseif($survey->yes>7 & $survey->yes<15): ?>
        	<p>
        		<strong>Status :</strong>
        		<label id="status">Resiko Sedang</label>
        	</p>
        	<?php else: ?>
        	<p>
        		<strong>Status :</strong>
        		<label id="status">Resiko Tinggi</label>
        	</p>
        <?php endif; ?>
    </center>

	<?php if(auth()->guard()->guest()): ?>
    <?php else: ?>
    <a style="margin-top: 15px;" class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="fa fa-sign-out"></i> <?php echo e(__('Logout')); ?> </a>
    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
    <?php echo csrf_field(); ?>
    </form>
    <?php endif; ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\L6-covid19\resources\views/result.blade.php ENDPATH**/ ?>